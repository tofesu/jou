<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Setor;
class Assunto extends Model
{
   
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['assunto','descricao'];
    
    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
//    protected $casts = [
//        'setor_id' => 'int',
//    ];
    public function setor() {
        return $this->belogsTomany('App\Setor');
    }
    

    
}