<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssuntoSetor extends Model
{
    protected $table='assunto_setor';
    
}
