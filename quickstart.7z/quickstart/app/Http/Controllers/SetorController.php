<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Repositories\SetorRepository;
use App\Setor;

class SetorController extends Controller
{
    /**
     * The setor repository instance.
     *
     * @var TaskRepository
     */
    protected $setors;

    /**
     * Create a new controller instance.
     *
     * @param  TaskRepository  $setors
     * @return void
     */
    public function __construct(SetorRepository $setors)
    {
        $this->middleware('auth');

        $this->setors = $setors;
    }

    /**
     * Display a list of all of the user's setor.
     *
     * @param  Request  $request
     * @return Response
     */
    public function index(Request $request)
    {
        return view('setor.index', [
            'setores' => $this->setors->forUser($request->user()),
        ]);
    }

    /**
     * Create a new setor.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:255',
        ]);

        $request->user()->setors()->create([
            'nome' => $request->nome,
        ]);

        return redirect('/setor');
    }

    /**
     * Destroy the given setor.
     *
     * @param  Request  $request
     * @param  Task  $setor
     * @return Response
     */
    public function destroy(Request $request, Setor $setor)
    {
        $this->authorize('destroy', $setor);

        $setor->delete();

        return redirect('/setor');
    }
}
