<?php

namespace App\Permissao;

use Illuminate\Database\Eloquent\Model;

class Permissao extends Model
{
     /**
     *  A tabela no banco de dados utilizado neste model
     *
     * @var string
     */
    protected $table = 'permissoes';

    /*
    |--------------------------------------------------------------------------
    | Métodos de Relacionamentos
    |--------------------------------------------------------------------------
    */

    /**
      * Método relacionamento varios para vários.
     *
     * @return QueryBuilder
     */
    public function regras()
    {
        return $this->belongsToMany('App\Regra');
    }
}
