<?php

namespace App\Regra;

use Illuminate\Database\Eloquent\Model;

class Regra extends Model
{
    /**
     * A tabela no banco de dados utilizado neste model
     *
     * @var string
     */
    protected $table = 'regras';

    /*
    |--------------------------------------------------------------------------
    | Métodos de Relacionamentos
    |--------------------------------------------------------------------------
    */

    /**
     * Método relacionamento varios para vários.
     *
     * @return QueryBuilder
     */
    public function users()
    {
        return $this->belongsToMany('App\User');
    }

    /**
     * Método relacionamento varios para vários.
     *
     * @return QueryBuilder
     */
    public function permissoes()
    {
        return $this->belongsToMany('App\Permissao');
    }
}