<?php

namespace App\Repositories;

/**
 * Description of SetorRepository
 *
 * @author twh
 */
use App\User;
use App\Setor;

class SetorRepository 
  {
    
    /**
     * Get all of the sectors for a given user.
     *
     * @param  User  $user
     * @return Collection
     */
    public function forUser(User $user)
    {
        return Setor::where('id', $user->id_setor)
                    ->orderBy('created_at', 'asc')
                    ->get();
    }
}