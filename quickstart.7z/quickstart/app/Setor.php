<?php

namespace App;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Setor extends Model
{
    
            /*
     * A tabela no banco de dados utilizado neste model
     *
     * @var string
     */
    protected $table = 'setor';
    /*
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['nome'];
    // protected $hidden = []; /*campos ocultos*/
    
    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'user_id' => 'int',
    ];

    /**
     * Get the user that owns the setor.
     */
    public function user()
    {
        return $this->hasMany(User::class);
    }
    public function assunto(){
        return $this->belongsToMany('App\Assunto');
    }
}
