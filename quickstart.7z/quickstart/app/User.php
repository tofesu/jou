<?php

namespace App;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Authenticatable;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;

class User extends Model implements AuthenticatableContract, CanResetPasswordContract
{
    use Authenticatable, CanResetPassword, SoftDeletes;
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'users';
    protected $fillable = ['nome', 'sobrenome', 'email','cpf',];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token','id_setor',
    ];

    /**
     * Get all of the tasks for the user.
     */
    public function tasks()
    {
        return $this->hasMany(Task::class);
    }
    /* 
    |-------------------------------------------------------
    | Métodos ACL ()
    |-------------------------------------------------------
    */

    /*verificar permissao*/
    public function pode($permissao = null){
        return !is_null($permissao) && $this->verificaPermissao($permissao);
    }

    /**
    * Verifica se algum usuario tem a permissao
    * @param String slug de uma permissao 
    * @return Boolean true se existe e false se não
    */
protected function VerificaPermissao($perm)
    {
        $permissions = $this->verificaTodasPermissoes();
        
        $permissionArray = is_array($perm) ? $perm : [$perm];

        return count(array_intersect($permissions, $permissionArray));
    }
    /**
     * Get all permission slugs from all permissions of all roles
     *
     * @return Array of permission slugs
     */
    protected function verificaTodasPermissoes($permi){
        $permissoesArray = [];
        $permissoes = $this->regras->load('permissoes')->fetch('permissoes')->toArray();
        return array_map('strlower', array_unique(array_flatten(array_map(function($permissao){
            return array_fetch($permissao,'slug');
        },$permissoes))));
    }
  
    /*
    |-------------------------------------
    | Métodos de Relacionamentos
    |-------------------------------------
    */
    public function regras(){
         return $this->belongsToMany('App\Regras');
    }


}
