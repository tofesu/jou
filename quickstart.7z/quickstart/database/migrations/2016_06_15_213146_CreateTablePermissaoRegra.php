<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTablePermissaoRegra extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('permissao_regra', function(Blueprint $table)

          {
             $table->increments('id');
             $table->integer('permissao_id');
             $table->integer('regra_id');
             $table->timestamps();
          });    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('permissao_regra');
    }
}
