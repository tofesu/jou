<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableAssuntoSetor extends Migration
{
 /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('assunto_setor', function(Blueprint $table)

          {
             $table->increments('id');
             $table->integer('setor_id');
             $table->integer('assunto_id');
             $table->timestamps();
          });    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('assunto_setor');
    }
}