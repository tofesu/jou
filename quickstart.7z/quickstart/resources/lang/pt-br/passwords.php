<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'password' => 'Senhas devem ter no mínimo 6 caracteres e ser confirmadas.',
    'reset' => 'Sua senha foi alterada',
    'sent' => 'Um email com um link para alterar sua senha, foi enviado',
    'token' => 'Chave de reset chave invalida.',
    'user' => "Não foi encontrado um usuário para este endereço de email.",

];
