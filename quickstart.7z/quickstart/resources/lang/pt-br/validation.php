<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */

    'accepted'             => 'O :attribute precisa ter accepted.',
    'active_url'           => 'Endereço :attribute não é uma URL válida.',
    'after'                => 'Valor em :attribute precisa ser uma data posterior a :date.',
    'alpha'                => 'Valor em :attribute permite apenas letras.',
    'alpha_dash'           => 'Valor em :attribute permite apenas letras, números, e espaços.',
    'alpha_num'            => 'Valor em :attribute permite apenas letras e números.',
    'array'                => 'Valor em :attribute precisa ser um vetor.',
    'before'               => 'Valor em :attribute precisa ser uma data anterior a :date.',
    'between'              => [
        'numeric' => 'Valor :attribute deve ter no mínimo :min e no máximo :max .',
        'file'    => 'Arquivo :attribute deve ter no mínimo :min e no máximo :max  kilobytes.',
        'string'  => 'Campo :attribute deve ter no mínimo :min e no máximo :max  caracteres.',
        'array'   => 'Campo :attribute deve ter no mínimo :min e no máximo :max  itens.',
    ],
    'boolean'              => 'Campo :attribute precisa ter valor verdadeiro ou falso.',
    'confirmed'            => 'Campo :attribute confirmação não confere.',
    'date'                 => 'Campo :attribute não é uma data válida.',
    'date_format'          => 'Campo :attribute não esta no formato :format.',
    'different'            => 'Campos :attribute e :other devem ser diferentes.',
    'digits'               => 'Campo :attribute deve conter :digits digitos.',
    'digits_between'       => 'Campo :attribute deve ter no mínimo :min e no máximo :max digitos.',
    'email'                => 'Campo :attribute deve ser um endereço de email válido.',
    'exists'               => 'O campo selecionado :attribute é inválido.',
    'filled'               => 'O campo :attribute é requerido.',
    'image'                => 'O campo :attribute deve ser uma imagem.',
    'in'                   => 'O campo selecionado :attribute é inválido.',
    'integer'              => 'O :attribute deve ser inteiro.',
    'ip'                   => 'O :attribute deve ser um IP válido.',
    'json'                 => 'O :attribute deve ser um JSON válido.',
    'max'                  => [
        'numeric' => 'O :attribute não pode ser maior que :max.',
        'file'    => 'O :attribute não pode ser maior que :max kilobytes.',
        'string'  => 'O :attribute não pode ser maior que :max characters.',
        'array'   => 'O :attribute não pode conter mais que :max itens.',
    ],
    'mimes'                => 'O :attribute deve ser uma arquivo do tipo: :values.',
    'min'                  => [
        'numeric' => 'O :attribute deve ter no mínimo.',
        'file'    => 'O :attribute deve ter no mínimo kilobytes.',
        'string'  => 'O :attribute deve ter no mínimo caracteres.',
        'array'   => 'O :attribute deve ter no mínimo :min itens.',
    ],
    'not_in'               => 'O :attribute selecionado é inválido.',
    'numeric'              => 'O :attribute precisa ter um número.',
    'regex'                => 'O formato de :attribute é inválido.',
    'required'             => 'O campo :attribute é obrigatório.',
    'required_if'          => 'O campo :attribute é obrigatório quando :other é :value.',
    'required_unless'      => 'O campo :attribute é obrigatório a menos que :other esteja em :values.',
    'required_with'        => 'O campo :attribute é obrigatório quando  :values está presente.',
    'required_with_all'    => 'O campo :attribute é obrigatório quando  :values está presente.',
    'required_without'     => 'O campo :attribute é obrigatório quando :values não está presente.',
    'required_without_all' => 'O campo :attribute é obrigatório quando nenhum de :values estão presentes.',
    'same'                 => 'O :attribute e :other precisam ser os mesmos.',
    'size'                 => [
        'numeric' => 'O :attribute precisa ter :size.',
        'file'    => 'O :attribute precisa ter :size kilobytes.',
        'string'  => 'O :attribute precisa ter :size characters.',
        'array'   => 'O :attribute precisa conter :size itens.',
    ],
    'string'               => 'O :attribute precisa ser uma string.',
    'timezone'             => 'O :attribute precisa ser uma zona válida.',
    'unique'               => 'O :attribute precisa realmente se obtido.',
    'url'                  => 'O formato de :attribute é invalido.',

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | Here you may specify custom validation messages for attributes using the
    | convention "attribute.rule" to name the lines. This makes it quick to
    | specify a specific custom language line for a given attribute rule.
    |
    */

    'custom' => [
        'attribute-name' => [
            'rule-name' => 'custom-message',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Attributes
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to swap attribute place-holders
    | with something more reader friendly such as E-Mail Address instead
    | of "email". This simply helps us make messages a little cleaner.
    |
    */

    'attributes' => [],

];
