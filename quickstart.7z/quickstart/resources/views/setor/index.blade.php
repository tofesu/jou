@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="col-sm-offset-2 col-sm-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Novo Setor
                </div>

                <div class="panel-body">
                    <!-- Display Validation Errors -->
                    @include('common.errors')

                    <!-- New Task Form -->
                    <form action="{{ url('setor') }}" method="POST" class="form-horizontal">
                        {{ csrf_field() }}

                        <!-- Task Name -->
                        <div class="form-group">
                            <label for="setor-name" class="col-sm-3 control-label">Setor</label>

                            <div class="col-sm-6">
                                <input type="text" name="name" id="setor-name" class="form-control" value="{{ old('setor') }}">
                            </div>
                        </div>

                        <!-- Add Task Button -->
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-6">
                                <button type="submit" class="btn btn-default">
                                    <i class="fa fa-btn fa-plus"></i>Adicionar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Current Tasks -->
            @if (count($setores) > 0)
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Setores Ativos
                    </div>

                    <div class="panel-body">
                        <table class="table table-striped setor-table">
                            <thead>
                                <th>Setor</th>
                                <th>&nbsp;</th>
                            </thead>
                            <tbody>
                                @foreach ($setores as $setor)
                                    <tr>
                                        <td class="table-text"><div>{{ $setor->nome }}</div></td>

                                        <!-- Task Delete Button -->
                                        <td>
                                            <form action="{{url('setor/' . $setor->id)}}" method="POST">
                                                {{ csrf_field() }}
                                                {{ method_field('DELETE') }}

                                                <button type="submit" id="delete-setor-{{ $setor->id }}" class="btn btn-danger">
                                                    <i class="fa fa-btn fa-trash"></i>Apagar
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            @endif
        </div>
    </div>
@endsection
