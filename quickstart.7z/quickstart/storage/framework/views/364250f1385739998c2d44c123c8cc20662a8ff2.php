<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-sm-offset-2 col-sm-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Novo Setor
                </div>

                <div class="panel-body">
                    <!-- Display Validation Errors -->
                    <?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <!-- New Task Form -->
                    <form action="<?php echo e(url('setor')); ?>" method="POST" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>


                        <!-- Task Name -->
                        <div class="form-group">
                            <label for="setor-name" class="col-sm-3 control-label">Setor</label>

                            <div class="col-sm-6">
                                <input type="text" name="name" id="setor-name" class="form-control" value="<?php echo e(old('setor')); ?>">
                            </div>
                        </div>

                        <!-- Add Task Button -->
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-6">
                                <button type="submit" class="btn btn-default">
                                    <i class="fa fa-btn fa-plus"></i>Adicionar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Current Tasks -->
            <?php if(count($setores) > 0): ?>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Setores Ativos
                    </div>

                    <div class="panel-body">
                        <table class="table table-striped setor-table">
                            <thead>
                                <th>Setor</th>
                                <th>&nbsp;</th>
                            </thead>
                            <tbody>
                                <?php foreach($setores as $setor): ?>
                                    <tr>
                                        <td class="table-text"><div><?php echo e($setor->nome); ?></div></td>

                                        <!-- Task Delete Button -->
                                        <td>
                                            <form action="<?php echo e(url('setor/' . $setor->id)); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>


                                                <button type="submit" id="delete-setor-<?php echo e($setor->id); ?>" class="btn btn-danger">
                                                    <i class="fa fa-btn fa-trash"></i>Apagar
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>